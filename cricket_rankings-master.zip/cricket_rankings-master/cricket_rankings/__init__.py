from .rankings import rankings

__name__ = 'cricket_rankings'
__version__ = '1.0.3'
__author__ = 'Umang Ahuja'
